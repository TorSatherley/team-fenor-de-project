import pandas as pd


df = pd.read_json("data/json_files/transaction.json")
df.to_json("transaction.jsonl", orient="records", lines=True)




# import boto3
# from datetime import date, datetime
# from pprint import pprint

# bucket_name = "totesys-processed-zone-fenor"
# s3 = boto3.client("s3")


# # # s3://data/XXXX_XXXX/address.json
# BUCKET_NAME = 'totesys-ingestion-zone-fenor'
# PREFIX = 'data/'

# def get_latest_folder():
#     response = s3.list_objects_v2(Bucket=BUCKET_NAME, Prefix=PREFIX, Delimiter="/")
    
#     data_folders = [
#         "data/240228_2330/",
#         "data/240228_2400/",
#         "data/240229_0030/",
#         "data/240229_0100/",
#         "data/240229_0130/",
#         "data/240229_0200/",
#         "data/240229_0230/",
#         "data/240229_0300/",
#         "data/240229_2330/",
#         "data/240301_0000/",
#         "data/240301_0030/",
#         "data/240301_0100/",
#         "data/240301_0130/",
#         "data/240301_0200/",
#         "data/240301_0230/",
#         "data/240301_0300/",
#         "data/240301_2330/",
#         "data/240302_0000/",
#         "data/240302_0030/",
#         "data/240302_0100/"
#     ]

#     # folders = [folder for folder in data_folders]
#     folders = [folder['Prefix'] for folder in response['CommonPrefixes']]
#     folders.sort(reverse=True)
    
#     latest_folder = folders[0]

#     return latest_folder


# print("Latest folder:", get_latest_folder())



# print(current_date, current_time)
# folder = 
# print(current_date)
# def load_json_files():
#     pass


# def lambda_handler(event, context):
    
#     data_folder_key = "data/"
#     log_folder_key = "log/"

#     data = "Hello from FenorLand"
#     data_batch_file = f"{data_folder_key}{datetime.datetime.now().isoformat()}.json"
#     s3.put_object(Bucket=bucket_name, Key=data_batch_file, Body=data)

#     log_file = f"{log_folder_key}{datetime.datetime.now().isoformat()}.log"
#     s3.put_object(Bucket=bucket_name, Key=log_file, Body=data)

#     print({"log": "Files Transformed successfully - {datetime.now()}"})
#     return {
#         "message": f"Processed Files in s3://{bucket_name}"
#     }